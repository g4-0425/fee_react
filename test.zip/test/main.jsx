import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import { App } from "./App.jsx";

import { ToastContainer } from "react-toastify"
import "react-toastify/dist/ReactToastify.css"

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <ToastContainer
      theme="light"
      position="top-center"
      autoClose={2000}
    />
    <App />
  </StrictMode>
);
