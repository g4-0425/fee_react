
import { IoMdLogOut } from "react-icons/io";
import {useAuthStore} from "./useAuthStore"; 
import { NavLink,Outlet,useNavigate } from "react-router-dom";
import {toast} from "react-toastify";

export function Nav1(){
    const user = useAuthStore((state)=>state.userName);
 const logout = useAuthStore((state)=>state.logout);
 const navigate = useNavigate(); 
 function handleClick(){
    logout();
    toast.success("Logged Out Successfully");
    setTimeout(()=>{
        navigate("/");
    },1500);
 }
 return(
    <div>
    <div className="bh5 fxc jsb p2">
 <div className="fs1">&#9812; </div>
<div>
    <NavLink to="/about"> About </NavLink> 
    <NavLink to="/products"> Products </NavLink>
    <NavLink to="/about"> Contact Us </NavLink>
</div>
<div className="fxc">
<div>{user} </div>
<button onClick={handleClick} className="btn4 bg70 fsm fyc">
    <IoMdLogOut/>
</button>
</div>
</div>
<div className="h95"> <Outlet/>
</div>
    </div>
 );

}
